编译选项
	./configure --enable-netbeans --enable-multibyte --enable-fontset --with-vim-name=vi --with-features=huge  --enable-luainterp --enable-perlinterp --enable-pythoninterp --enable-python3interp --enable-tclinterp --enable-rubyinterp  --enable-cscope   --enable-hangulinput --enable-fontset


